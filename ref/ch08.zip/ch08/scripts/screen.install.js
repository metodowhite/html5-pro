jewel.screens["install-screen"] = (function() {
    return {
        run : function() {}
    };
})();
